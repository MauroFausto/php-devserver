<?php
	interface componente
	{
		public function criar();
	}
?>