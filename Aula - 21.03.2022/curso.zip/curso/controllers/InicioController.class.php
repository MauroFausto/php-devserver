<?php
	class InicioController
	{
		public function MostrarMenu()
		{
			require_once "views/menu.html";
		}
	}
?>