<!doctype html>
<html>
	<head>
		<title>Lista de Alunos</title>
	</head>
	<body>
	<?php
		if(isset($_GET["msg"]))
		{
			echo "<h3>{$_GET['msg']}</h3><br>";
		}
	?>
		<h2>Lista de Alunos</h2>
		<table border="1">
			<tr>
				<th>Id</th>
				<th>Nome</th>
				<th>CPF</th>
				<th>Data de Nascimento</th>
				<th>Ações</th>
			</tr>
			<?php
				if(is_array($retorno))
				{
					foreach($retorno as $dado)
					{
						echo "<tr>";
						echo "<td>{$dado->idaluno}</td>";
						echo "<td>{$dado->nome}</td>";
						echo "<td>{$dado->cpf}</td>";
						echo "<td>{$dado->dataNascimento}</td>";
						
						echo "<td><a href='index.php?controle=AlunoController&metodo=alterar&id={$dado->idaluno}'>Alterar</a></td>";
						
						echo "</tr>";
					}
				}
				else
					echo "<h2>$retorno</h2>";
			?>
		</table>
		<a href="index.php?controle=AlunoController&metodo=inserir">Novo Aluno</a>
	</body>
</html>