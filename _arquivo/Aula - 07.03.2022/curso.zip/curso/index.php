<?php
	require_once "controllers/CursoController.class.php";
	$obj = new CursoController();
	$obj->listar();
?>