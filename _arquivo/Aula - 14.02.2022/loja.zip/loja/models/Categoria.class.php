<?php
	class Categoria
	{
		//atributos
		private $idcategoria;
		private $descritivo;
		

		//métodos
		
		//método construtor
		public function __construct($idcategoria, $descritivo)
		{
			$this->idcategoria = $idcategoria;
			$this->descritivo = $descritivo;
			
		}
		//gets e sets
		
		public function getIdCategoria()
		{
			return $this->idcategoria;
		}
		public function getDescritivo()
		{
			return $this->descritivo;
		}
		
		public function setId($idcategoria)
		{
			$this->idcategoria = $idcategoria;
		}
		public function setDescritivo($descritivo)
		{
			$this->descritivo = $descritivo;
		}
		
		
	}//fim classe
?>