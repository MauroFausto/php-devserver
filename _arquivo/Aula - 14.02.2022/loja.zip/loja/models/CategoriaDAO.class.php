<?php
	class CategoriaDAO extends Conexao
	{
		
		public function __construct()
		{
			parent:: __construct();
		}
		public function inserir($categoria)
		{
			$sql = "INSERT INTO categoria (descritivo) VALUES(?)";
			$comando = $this->conexao->prepare($sql);
			$comando->bindValue(1, $categoria->getDescritivo());
						
			$comando->execute();
			//fechar a conexao
			
			$this->conexao = null;
			
			return "categoria inserida com sucesso";
			
			
		}
		public function alterar($categoria)
		{
			$sql = "UPDATE categoria SET descritivo = ? WHERE idcategoria = ?";
			$comando = $this->conexao->prepare($sql);
			$comando->bindValue(1, $categoria->getDescritivo());
			$comando->bindValue(2, $categoria->getIdCategoria());
			$comando->execute();
			$this->conexao = null;
			return "Categoria Alterada com sucesso";
		}
		
		public function excluir($categoria)
		{
			$sql = "DELETE FROM categoria WHERE idcategoria = ?";
			$comando = $this->conexao->prepare($sql);
			$comando->bindValue(1, $categoria->getIdcategoria());
			$comando->execute();
			$this->conexao = null;
			return "Categoria Excluida com sucesso";
		}
		public function consultar()
		{
			$sql = "SELECT * FROM categoria";
			$comando = $this->conexao->prepare($sql);
			$comando->execute();
			$resultado = $comando->fetchAll(PDO::FETCH_OBJ);
			$this->conexao = null;
			return $resultado;		
		}
		
		public function buscarUmcategoria($categoria)
		{
			$sql = "SELECT * FROM categoria WHERE idcategoria = ?";
			$comando = $this->conexao->prepare($sql);
			$comando->bindValue(1, $categoria->getIdcategoria());
			$comando->execute();
			$resultado = $comando->fetchAll(PDO::FETCH_OBJ);
			$this->conexao = null;
			return $resultado;	
		}
	}
?>