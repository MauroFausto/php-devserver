<?php
	abstract class Conexao
	{
		protected $conexao;
		
		protected function __construct()
		{
			$parametros = "mysql:host=localhost;dbname=bd_produto;charset=utf8mb4";
			$this->conexao = new PDO($parametros, "root", "");
		}
			
	}
?>