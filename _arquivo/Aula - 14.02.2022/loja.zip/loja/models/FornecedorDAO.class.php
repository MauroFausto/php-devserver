<?php
	class FornecedorDAO extends Conexao
	{
		public function __construct()
		{
			parent:: __construct();
		}
		public function inserir($fornecedor)
		{
			$sql = "INSERT INTO fornecedor (razao_social, cnpj, telefone) VALUES(?, ?, ?)";
			$comando = $this->conexao->prepare($sql);
			$comando->bindValue(1, $fornecedor->getRazaoSocial());
			$comando->bindValue(2, $fornecedor->getCnpj());
			$comando->bindValue(3, $fornecedor->getTelefone());
			
			$comando->execute();
			return "Fornecedor inserido com sucesso";
			
			
		}
		public function alterar($fornecedor)
		{
			$sql = "UPDATE fornecedor SET razao_social = ?, cnpj = ?, telefone = ? WHERE idfornecedor = ?";
			$comando = $this->conexao->prepare($sql);
			$comando->bindValue(1, $fornecedor->getRazaoSocial());
			$comando->bindValue(2, $fornecedor->getCnpj());
			$comando->bindValue(3, $fornecedor->getTelefone());
			$comando->bindValue(4, $fornecedor->getId());
			
			$comando->execute();
			return "Fornecedor Alterado com sucesso";
		}
		
		public function excluir($fornecedor)
		{
			$sql = "DELETE FROM fornecedor WHERE idfornecedor = ?";
			$comando = $this->conexao->prepare($sql);
			$comando->bindValue(1, $fornecedor->getId());
			$comando->execute();
			return "Fornecedor Excluido com sucesso";
		}
		public function consultar()
		{
			$sql = "SELECT * FROM fornecedor";
			$comando = $this->conexao->prepare($sql);
			$comando->execute();
			$resultado = $comando->fetchAll(PDO::FETCH_OBJ);
			return $resultado;		
		}
		
		public function buscarUmFornecedor($fornecedor)
		{
			$sql = "SELECT * FROM fornecedor WHERE idfornecedor = ?";
			$comando = $this->conexao->prepare($sql);
			$comando->bindValue(1, $fornecedor->getId());
			$comando->execute();
			$resultado = $comando->fetchAll(PDO::FETCH_OBJ);
			return $resultado;	
		}
		
	}
?>