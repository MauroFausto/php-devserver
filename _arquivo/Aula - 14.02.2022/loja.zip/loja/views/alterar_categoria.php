<?php
	if($_POST)
	{
		//verificar os dados enviados
		require_once "../models/Conexao.class.php";
		require_once "../models/Categoria.class.php";
		require_once "../models/CategoriaDAO.class.php";
		$categoria = new Categoria($_POST["id"], $_POST["descritivo"]);
		$categoriaDAO = new CategoriaDAO();
		
		$retorno = $categoriaDAO->alterar($categoria);
		
		header("Location:listar_Categoria.php?msg=$retorno");
	}
	else
	{
		header("Location:listar_Categoria.php");
	}
?>