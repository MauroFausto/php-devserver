<?php
	if($_POST)
	{
		//verificar os dados enviados
		require_once "../models/Conexao.class.php";
		require_once "../models/Produto.class.php";
		require_once "../models/ProdutoDAO.class.php";
		require_once "../models/Categoria.class.php";
		
		$categoria = new Categoria($_POST["categoria"], null);
		$produto = new Produto($_POST["id"], $_POST["nome"], $_POST["descricao"], $_POST["preco"], $_POST["desconto"], $categoria);
		
		$produtoDAO = new ProdutoDAO();
		
		$retorno = $produtoDAO->alterar($produto);
		
		header("Location:listar_produto.php?msg=$retorno");
	}
	else
	{
		header("Location:listar_produto.php");
	}
?>