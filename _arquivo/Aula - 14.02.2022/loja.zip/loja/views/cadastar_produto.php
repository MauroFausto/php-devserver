<?php
	if($_POST)
	{
		//verificações
		require_once "../models/Conexao.class.php";
		require_once "../models/Produto.class.php";
		require_once "../models/ProdutoDAO.class.php";
		require_once "../models/Categoria.class.php";
		require_once "../models/Fornecedor.class.php";
		
		if($_POST["categoria"] != "0")
		{
			$categoria = new Categoria($_POST["categoria"], null);
			
			$produto = new produto(null, $_POST["nome"], $_POST["descricao"], $_POST["preco"], $_POST["desconto"], $categoria);
			
			if(isset($_POST["fornecedor"]))
			{
				foreach($_POST["fornecedor"] as $dado)
				{
					$fornecedor = new Fornecedor($dado, null, null, null);
					$produto->setFornecedor($fornecedor);
				}
				$produtoDAO = new ProdutoDAO();
			
				$retorno = $produtoDAO->inserir($produto);
			
				header("location:listar_produto.php?msg=$retorno");
			}
			else
			{
				echo "<script>alert('Escolha pelo Menos um Fornecedor')</script>";
			}
			
			
		}
		else
		{
			echo "<script>alert('Escolha uma categoria')</script>";
		}
	}
	else
	{
		header("location:listar_produto.php");
	}
?>