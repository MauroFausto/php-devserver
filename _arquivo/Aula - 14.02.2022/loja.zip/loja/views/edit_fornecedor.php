﻿<?php
	if($_GET)
	{
		require_once "../models/Conexao.class.php";
		require_once "../models/Fornecedor.class.php";
		require_once "../models/FornecedorDAO.class.php";
		$fornecedor = new Fornecedor($_GET["id"], null, null, null);
		$fornecedorDAO = new FornecedorDAO();
		
		$ret = $fornecedorDAO->buscarUmFornecedor($fornecedor);
		
	}
	else
	{
		header("Location:listar_Fornecedor.php");
	}
	require_once "cabecalho.php";
?>
<div class="content">
	<div class="container">
			
		<br><br><h1 class="row justify-content-center align-items-center">Fornecedor</h1>
			<br><br>
		<form action="alterar_Fornecedor.php" method="post">
			<input type="hidden" name="id" value="<?php echo $ret[0]->idfornecedor;?>">
			<div class="box">
		<div class="form-group">
			<div class="row justify-content-center align-items-center">
			<label class="col-sm-2 col-form-label col-form-label-lg">Razao Social:</label>
			<div class="col-sm-6">
			<input type="text" name="razao" value="<?php echo $ret[0]->razao_social;?>" class="form-control form-control-lg" required></div></div></div><br><br>
			<div class="form-group">
			<div class="row justify-content-center align-items-center">
					
			<label class="col-sm-2 col-form-label col-form-label-lg">CNPJ:</label>
			<div class="col-sm-6">
			<input type="text" name="cnpj" value="<?php echo $ret[0]->cnpj;?>" class="form-control form-control-lg"></div></div></div><br><br>
			<div class="form-group">
			<div class="row justify-content-center align-items-center">
			<label class="col-sm-2 col-form-label col-form-label-lg">Telefone:</label>
			<div class="col-sm-6">
			<input type="text" name="telefone" value="<?php echo $ret[0]->telefone;?>" class="form-control form-control-lg">
			</div></div></div><br><br>
			
			<div class="form-group">
			<div class="row justify-content-center align-items-center">
			<input type="submit"  class="btn btn-lg btn-success col-sm-2" value="Alterar">
		</div>
		</div>
	 </div>
	</form>
<?php
	require_once "rodape.html";
?>