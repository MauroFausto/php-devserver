<?php
	if($_GET)
	{
		require_once "../models/Conexao.class.php";
		require_once "../models/Fornecedor.class.php";
		require_once "../models/FornecedorDAO.class.php";
		
		$fornecedor = new Fornecedor($_GET["id"], null, null, null);
		$fornecedorDAO = new FornecedorDAO();
		
		$retorno = $fornecedorDAO->excluir($fornecedor);
		
		header("Location:listar_Fornecedor.php?msg=$retorno");
	}
	else
	{
		header("Location:listar_Fornecedor.php");
	}
?>