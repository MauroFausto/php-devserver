﻿<?php
	require_once "cabecalho.php";
?>

	<div class="content">
	<div class="container">
	<br><br><div class="row justify-content-center align-items-center">
		
      <h1 class="row justify-content-center align-items-center">Categoria</h1><br>
  </div><br><br>
	<form action="#" method="POST">
		
		<div class="box">
			
			<div class="form-group">
			<div class="row justify-content-center align-items-center">
				<label class="col-sm-2 col-form-label col-form-label-lg">Descritivo</label>
				<div class="col-sm-6">
					<input type="text"  class="form-control form-control-lg" name="descritivo">
				</div>
			</div>
			</div>
		
		<br><br><div class="form-group">
		<div class="row justify-content-center align-items-center">
			<input type="submit"  class="btn btn-lg btn-success col-sm-2" value="Inserir">
		</div>
		</div>
	</div>
</form>
<?php
	require "rodape.html";
?>