﻿<?php
	require_once "cabecalho.php";
?>
	<div class="content">
		<div class="container">
			
				<br><br><h1 class="row justify-content-center align-items-center">Fornecedor</h1>
			<br><br>
		<form action="cadastar_fornecedor.php" method="post">
		<div class="box">
		<div class="form-group">
			<div class="row justify-content-center align-items-center">
			<label class="col-sm-2 col-form-label col-form-label-lg">Razão Social:</label>
			<div class="col-sm-6">
				<input type="text" name="razao" class="form-control form-control-lg" required>
			</div>
		</div></div><br><br>
		<div class="form-group">
			<div class="row justify-content-center align-items-center">
			<label class="col-sm-2 col-form-label col-form-label-lg">CNPJ:</label>
			<div class="col-sm-6">
				<input type="text" class="form-control form-control-lg" name="cnpj" required>
			</div>
		</div></div><br><br>
		<div class="form-group">
			<div class="row justify-content-center align-items-center">
			<label class="col-sm-2 col-form-label col-form-label-lg">Telefone:</label>
			<div class="col-sm-6">
				<input type="text" name="telefone" class="form-control form-control-lg" required>
			</div>
		</div></div>
		
			<br><br>
			<div class="form-group">
		<div class="row justify-content-center align-items-center">
			<input type="submit"  class="btn btn-lg btn-success col-sm-2" value="Enviar">
		</div>
		</div>
	</div>
		</form>
<?php
	require_once "rodape.html";
?>