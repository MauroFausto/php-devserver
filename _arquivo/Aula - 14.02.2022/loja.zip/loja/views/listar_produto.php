<?php
	require_once "cabecalho.php";
?>
	<div class="content">
		<div class="container">
		<br><br><div class="row justify-content-center align-items-center">
		
      <h1 class="row justify-content-center align-items-center">Lista de Produtos</h1><br>
  </div><br><br>
		<div>
		<?php 
			if(isset($_GET["msg"]))
			{
				echo $_GET["msg"];
			}
		?>
		</div>
		<table class="table table-striped">
			<tr>
				<th>Produto</th>
				<th style="text-align:center;">Preço(R$)</th>
				<th style="text-align:center;">Desconto(%)</th>
				<th style="text-align:center;">Ações</th>
			</tr>
			<?php
				require_once "../models/Conexao.class.php";
				require_once "../models/ProdutoDAO.class.php";
				//criar o objeto produtoDAO
				$produtoDAO = new produtoDAO();
				
				//método consultar
				$retorno = $produtoDAO->consultar();
				//fechar a conexao
				
				/*echo "<pre>";
				var_dump($retorno);
				echo "</pre>";*/
				//criar as tds
				if(is_array($retorno))
				{
					foreach($retorno as $dado)
					{
						echo "<tr>";
						echo "<td>{$dado->nome}</td>";
						echo "<td style='text-align:center;'>{$dado->preco}</td>";
						echo "<td style='text-align:center;'>{$dado->desconto}</td>";
						echo "<td style='text-align:center;'>
						<a class='btn btn-warning btn-sm' href='edit_produto.php?id={$dado->idproduto}'>Alterar</a>&nbsp;&nbsp;";
					?>	
						
						
						</td>
						</tr>
					<?php
					}
				}
			?>
		</table>
		<br><br><a href="form_produto.php" class='btn btn-success btn-sm'>Novo Produto</a>
	</body>
</html>