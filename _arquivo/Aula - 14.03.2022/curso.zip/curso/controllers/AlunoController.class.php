<?php

	require_once "models/Conexao.class.php";
	require_once "models/AlunoDAO.class.php";
	require_once "models/Aluno.class.php";
	
	class AlunoController
	{
		public function listar()
		{
			$alunoDAO = new alunoDAO();
			$retorno = $alunoDAO->consultar();
			
			require_once "views/listar_aluno.php";
			
			
		}//fim listar
		
		public function inserir()
		{
			require_once "views/form_aluno.php";
			if($_POST)
			{
				//verificar o preenchimento dos dados
				$erro = 0;
				if(empty($_POST["nome"]))
				{
					$erro++;
					echo "<script>alert('Preencha o nome do aluno')</script>";
				}
				if($_POST["cpf"] == "")
				{
					$erro++;
					echo "<script>alert('Preencha o CPF do aluno')</script>";
				}
				if($_POST["data"] == "")
				{
					$erro++;
					echo "<script>alert('Preencha a data de nascimento do aluno')</script>";
				}
				if($erro == 0)
				{
					//inserir no BD
					$aluno = new Aluno(cpf:$_POST["cpf"], nome:$_POST["nome"], dataNascimento:$_POST["data"]);
					
					$alunoDAO = new AlunoDAO();
					$retorno = $alunoDAO->inserir($aluno);
					
					
				}
				
			}
		}
	}//fim da classe AlunoController
?>