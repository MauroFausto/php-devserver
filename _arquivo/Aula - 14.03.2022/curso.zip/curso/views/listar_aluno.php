<!doctyp html>
<html>
	<head>
		<title>Lista de Alunos</title>
	</head>
	<body>
		<h2>Lista de Alunos</h2>
		<table border="1">
			<tr>
				<th>Id</th>
				<th>Nome</th>
				<th>CPF</th>
				<th>Data de Nascimento</th>
			</tr>
			<?php
				if(is_array($retorno))
				{
					foreach($retorno as $dado)
					{
						echo "<tr>";
						echo "<td>{$dado->idaluno}</td>";
						echo "<td>{$dado->nome}</td>";
						echo "<td>{$dado->cpf}</td>";
						echo "<td>{$dado->dataNascimento}</td>";
						echo "</tr>";
					}
				}
				else
					echo "<h2>$retorno</h2>";
			?>
		</table>
		<a href="index.php?controle=AlunoController&metodo=inserir">Novo Aluno</a>
	</body>
</html>