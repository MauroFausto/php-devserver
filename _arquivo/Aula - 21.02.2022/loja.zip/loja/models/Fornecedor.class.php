<?php
	class Fornecedor
	{
		private $idFornecedor;
		private $razao_social;
		private $cnpj;
		private $telefone;
		
		
		public function __construct($id, $razao, $cnpj, $tel)
		{
			$this->idFornecedor = $id;
			$this->razao_social = $razao;
			$this->cnpj = $cnpj;
			$this->telefone = $tel;
			
		}
		//métodos gets
		public function getId()
		{
			return $this->idFornecedor;
		}
		public function getRazaoSocial()
		{
			return $this->razao_social;
		}
		public function getTelefone()
		{
			return $this->telefone;
		}
		public function getCnpj()
		{
			return $this->cnpj;
		}
		
	}
?>