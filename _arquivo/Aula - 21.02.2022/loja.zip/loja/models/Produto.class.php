<?php
	class Produto
	{
		//atributos
		private $idproduto;
		private $nome;
		private $descricao;
		private $preco;
		private $desconto;
		//atributo da associação
		private $fornecedor;
		private $categoria;

		//métodos
		
		//método construtor
		public function __construct($idproduto, $nome, $descricao, $preco, $desconto, $categoria)
		{
			$this->idproduto = $idproduto;
			$this->nome = $nome;
			$this->descricao = $descricao;
			$this->preco = $preco;
			$this->desconto = $desconto;
			$this->categoria = $categoria;
		}
		//gets e sets
		
		public function getIdproduto()
		{
			return $this->idproduto;
		}
		public function getNome()
		{
			return $this->nome;
		}
		public function getDescricao()
		{
			return $this->descricao;
		}
		public function getPreco()
		{
			return $this->preco;
		}
		public function getDesconto()
		{
			return $this->desconto;
		}
		public function getFornecedor()
		{
			return $this->fornecedor;
		}
		
		public function getCategoria()
		{
			return $this->categoria;
		}
		public function setId($idproduto)
		{
			$this->idproduto = $idproduto;
		}
		public function setNome($nome)
		{
			$this->nome = $nome;
		}
		public function setDescricao($descricao)
		{
			$this->descricao = $descricao;
		}
		public function setPreco($preco)
		{
			$this->preco = $preco;
		}
		public function setDesconto($desconto)
		{
			$this->desconto = $desconto;
		}
		
		public function setFornecedor($fornecedor)
		{
			$this->fornecedor[] = $fornecedor;
		}
		
		public function setCategoria($categoria)
		{
			$this->categoria = $categoria;
		}
		public function precoDesconto()
		{
			$preco = $this->preco - ($this->preco * $this->desconto/100);
			return $preco;
		}
		
	}//fim classe
?>