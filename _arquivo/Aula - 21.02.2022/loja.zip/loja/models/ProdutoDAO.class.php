<?php
	class ProdutoDAO extends Conexao
	{
		
		public function __construct()
		{
			parent:: __construct();
		}
		public function inserir($produto)
		{
			$sql = "INSERT INTO produto (idcategoria, nome, descricao, preco, desconto) VALUES(?, ?, ?, ?, ?)";
			$comando = $this->conexao->prepare($sql);
			$comando->bindValue(1, $produto->getCategoria()->getIdcategoria());
			$comando->bindValue(2, $produto->getNome());
			$comando->bindValue(3, $produto->getDescricao());
			$comando->bindValue(4, $produto->getPreco());
			$comando->bindValue(5, $produto->getDesconto());
			
			$comando->execute();
			//inserir produto_fornecedor
			$idproduto = $this->conexao->lastInsertId();
			
			$sql = "INSERT INTO produto_fornecedor (idproduto, idfornecedor) VALUES(?, ?)";
			
			
			$comando = $this->conexao->prepare($sql);
			
			foreach($produto->getFornecedor() as $dado)
			{
				$comando->bindValue(1, $idproduto);
				$comando->bindValue(2, $dado->getId());
				$comando->execute();
			}
			//fechar a conexao
			
			$this->conexao = null;
			
			return "Produto inserido com sucesso";
			
			
		}
		public function alterar($produto)
		{
			$sql = "UPDATE produto SET idcategoria = ?, nome = ?, descricao = ?, preco = ?, desconto = ? WHERE idproduto = ?";
			$comando = $this->conexao->prepare($sql);
			$comando->bindValue(1, $produto->getCategoria()->getIdCategoria());
			$comando->bindValue(2, $produto->getNome());
			$comando->bindValue(3, $produto->getDescricao());
			$comando->bindValue(4, $produto->getPreco());
			$comando->bindValue(5, $produto->getDesconto());
			$comando->bindValue(6, $produto->getIdproduto());
			$comando->execute();
			$this->conexao = null;
			return "Produto Alterado com sucesso";
		}
		
		
		public function consultar()
		{
			$sql = "SELECT * FROM produto";
			$comando = $this->conexao->prepare($sql);
			$comando->execute();
			$resultado = $comando->fetchAll(PDO::FETCH_OBJ);
			$this->conexao = null;
			return $resultado;		
		}
		
		public function buscarUmProduto($produto)
		{
			$sql = "SELECT * FROM produto WHERE idproduto = ?";
			$comando = $this->conexao->prepare($sql);
			$comando->bindValue(1, $produto->getIdproduto());
			$comando->execute();
			$resultado = $comando->fetchAll(PDO::FETCH_OBJ);
			$this->conexao = null;
			return $resultado;	
		}
	}
?>