<?php
	if($_POST)
	{
		//verificações
		require_once "../models/Conexao.class.php";
		require_once "../models/Categoria.class.php";
		require_once "../models/CategoriaDAO.class.php";
		
		
			$categoria = new Categoria(null, $_POST["descritivo"]);
			
			
				$categoriaDAO = new CategoriaDAO();
			
				$retorno = $categoriaDAO->inserir($categoria);
			
				header("location:listar_categoria.php?msg=$retorno");
			
	}
	else
	{
		header("location:listar_categoria.php");
	}
?>