﻿<?php
	if($_GET)
	{
		require_once "../models/Conexao.class.php";
		require_once "../models/Categoria.class.php";
		require_once "../models/CategoriaDAO.class.php";
		
		$categoria = new Categoria($_GET["id"], null);
		$categoriaDAO = new CategoriaDAO();
		
		$ret = $categoriaDAO->buscarUmCategoria($categoria);
		
	}
	else
	{
		header("Location:listar_Categoria.php");
	}
	require_once "cabecalho.php";
?>

	<div class="content">
	<div class="container">
	<br><br><div class="row justify-content-center align-items-center">
		
			<h1 class="row justify-content-center align-items-center">Categoria</h1><br>
			</div><br><br>
			<form action="alterar_Categoria.php" method="post">
			<div class="box">
			
				<input type="hidden" name="id" value="<?php echo $ret[0]->idcategoria;?>"><br>
						
			<div class="form-group">
			<div class="row justify-content-center align-items-center">
				<label class="col-sm-2 col-form-label col-form-label-lg">Descritivo:</label>
				<div class="col-sm-6">
					<input type="text" name="descritivo" class="form-control form-control-lg" value="<?php echo $ret[0]->descritivo;?>" required>
			
				</div>
			</div>
			</div>
			
			<br><br><div class="form-group">
			<div class="row justify-content-center align-items-center">
				<input type="submit"  class="btn btn-lg btn-success col-sm-2" value="Alterar">
			</div>
		</div>
	</div>
</form>
<?php
	require "rodape.html";
?>	