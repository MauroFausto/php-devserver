<?php
	if($_GET)
	{
		require_once "../models/Conexao.class.php";
		require_once "../models/Categoria.class.php";
		require_once "../models/CategoriaDAO.class.php";
		
		$categoria = new Categoria($_GET["id"], null);
		$categoriaDAO = new CategoriaDAO();
		
		$retorno = $categoriaDAO->excluir($categoria);
		
		header("Location:listar_Categoria.php?msg=$retorno");
	}
	else
	{
		header("Location:listar_Categoria.php");
	}
?>