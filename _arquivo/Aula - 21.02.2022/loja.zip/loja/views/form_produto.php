﻿<?php
	require_once "../models/Conexao.class.php";
	require_once "../models/FornecedorDAO.class.php";
	require_once "../models/CategoriaDAO.class.php";
	require_once "cabecalho.php";
?>
	<div class="content">
		<div class="container">
			
				<br><br><h1 class="row justify-content-center align-items-center">Produto</h1>
			<br><br>
		<form action="cadastar_produto.php" method="post">
		<div class="box">
		<div class="form-group">
			<div class="row justify-content-center align-items-center">
			<label class="col-sm-2 col-form-label col-form-label-lg">Nome do Produto:</label>
			<div class="col-sm-6">
			<input type="text" name="nome" class="form-control form-control-lg" required>
			</div>
		</div></div>
			
			<br><br>
			<div class="form-group">
			<div class="row justify-content-center align-items-center">
			<label class="col-sm-2 col-form-label col-form-label-lg">Descrição:</label><br>
			<div class="col-sm-6">
				<textarea class="form-control form-control-lg" name="descricao"></textarea>
			</div>
			</div></div><br><br>
			<div class="form-group">
			<div class="row justify-content-center align-items-center">
			<label class="col-sm-2 col-form-label col-form-label-lg">Categoria</label>
			<div class="col-sm-6">
			<select name="categoria">
			<option value="0">Escolha uma categoria</option>
			<?php
						
				$categoriaDAO = new categoriaDAO();
				$retorno = $categoriaDAO->consultar();
				if(is_array($retorno))
				{
					foreach($retorno as $dado)
					{
						echo "<option value='{$dado->idcategoria}'>{$dado->descritivo}</option>";
					}
				}
				
				
			?>
			
			</select>
			</div>
			</div></div>
			<br><br>
			<div class="form-group">
			<div class="row justify-content-center align-items-center">
			<label class="col-sm-2 col-form-label col-form-label-lg">Preço:</label>
			<div class="col-sm-6">
			<input type="text" name="preco" class="form-control form-control-lg">
			</div>
			</div></div>
			<br><br>
			<div class="form-group">
			<div class="row justify-content-center align-items-center">
			<label class="col-sm-2 col-form-label col-form-label-lg">Desconto:</label>
			<div class="col-sm-6">
			<input type="text" name="desconto" class="form-control form-control-lg">
			</div>
			</div></div>
			<br><br>
			<div class="row justify-content-center align-items-center">
			<div class="form-group col-md-8">
			<fieldset class="row border p-3">
			<legend>Fornecedor(es)</legend><br><br>
			<?php
				$fornecedorDAO = new FornecedorDAO();
				$ret = $fornecedorDAO->consultar();
				if(is_array($ret))
				{
					foreach($ret as $dado)
					{
						echo "<div class='form-group col-md-2'>
					
						<div class='form-check form-check-inline'>
						<input class='form-check-input' type='checkbox' name='fornecedor[]' value='{$dado->idfornecedor}'>";
						echo "<label class='form-check-label'>{$dado->razao_social}</label></div></div>";
					}
				}
			?>
			</div></div>
			</fieldset>
			
			<br><br>
			
			<div class="form-group">
			<div class="row justify-content-center align-items-center">
			<input type="submit"  class="btn btn-lg btn-success col-sm-2" value="Inserir">
		</div>
		</div>
	 </div>
	</form>
<?php
	require_once "rodape.html";
?>