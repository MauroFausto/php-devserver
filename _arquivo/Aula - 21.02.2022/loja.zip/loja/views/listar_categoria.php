<?php
	require_once "cabecalho.php";
?>
	<div class="content">
		<div class="container">
		<br><br><div class="row justify-content-center align-items-center">
		
      <h1 class="row justify-content-center align-items-center">Lista de Categorias</h1><br>
  </div><br><br>
		
		<div>
		<?php 
			if(isset($_GET["msg"]))
			{
				echo $_GET["msg"];
			}
		?>
		</div>
		<table class="table table-striped">
			<thead>
				<tr>
					<th>Categoria</th>
					
					<th style="text-align:center;">Ações</th>
				</tr>
			</thead>
			<tbody>
			<?php
				require_once "../models/Conexao.class.php";
				require_once "../models/CategoriaDAO.class.php";
				//criar o objeto categoriaDAO
				$categoriaDAO = new CategoriaDAO();
				
				//método consultar
				$retorno = $categoriaDAO->consultar();
				
				//criar as tds
				if(is_array($retorno))
				{
					foreach($retorno as $dado)
					{
						echo "<tr>";
						echo "<td>{$dado->descritivo}</td>";
						
						echo "<td style='text-align:center;'>
						<a href='edit_categoria.php?id={$dado->idcategoria}' class='btn btn-warning btn-sm'>Alterar</a>&nbsp;&nbsp;";
					?>	
						<a class='btn btn-danger btn-sm'href="excluir_categoria.php?id=<?php echo $dado->idcategoria; ?>" onclick="return confirm('Confirma a exclusão do produto?')">Excluir</a>
						
						</td>
						</tr>
					<?php
					}
				}
			?>
			</tbody>
		</table>
		<br><br><a href="form_categoria.php" class="btn btn-success btn-lg" >Nova Categoria</a>
	</body>
</html>