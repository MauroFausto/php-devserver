<?php
	class CategoriaDAO extends Conexao
	{
		
		public function __construct()
		{
			parent:: __construct();
		}
		public function inserir($categoria)
		{
			$sql = "INSERT INTO categoria (descritivo) VALUES(?)";
			$comando = $this->conexao->prepare($sql);
			$comando->bindValue(1, $categoria->getDescritivo());
						
			$ret = $comando->execute();
			//fechar a conexao
			
			$this->conexao = null;
			if($ret)
			{
				return "categoria inserida com sucesso";
			}
			else
			{
				return "Problema ao inserir a categoria";
			}
			
			
		}
		public function alterar($categoria)
		{
			$sql = "UPDATE categoria SET descritivo = ? WHERE idcategoria = ?";
			$comando = $this->conexao->prepare($sql);
			$comando->bindValue(1, $categoria->getDescritivo());
			$comando->bindValue(2, $categoria->getIdCategoria());
			$comando->execute();
			$this->conexao = null;
			return "Categoria Alterada com sucesso";
		}
		
		public function excluir($categoria)
		{
			$sql = "DELETE FROM categoria WHERE idcategoria = ?";
			try
			{
				$comando = $this->conexao->prepare($sql);
				$comando->bindValue(1, $categoria->getIdcategoria());
				$comando->execute();
				$this->conexao = null;
				return "Categoria Excluida com sucesso";
			}
			catch(PDOException $e)
			{
				if($e->getCode() == "23000")
				{
					return "Categoria não pode ser excluida, pois tem relação um produto";
				}
				else
				{
					return "Problema ao excluir a categoria";
				}
				//$msg = $e->getMessage() . "<br>" . $e->getCode();
				//return $msg;
			}
			
			
			
		}
		public function consultar()
		{
			$sql = "SELECT * FROM categoria";
			$comando = $this->conexao->prepare($sql);
			$comando->execute();
			$resultado = $comando->fetchAll(PDO::FETCH_OBJ);
			$this->conexao = null;
			return $resultado;		
		}
		
		public function buscarUmcategoria($categoria)
		{
			$sql = "SELECT * FROM categoria WHERE idcategoria = ?";
			$comando = $this->conexao->prepare($sql);
			$comando->bindValue(1, $categoria->getIdcategoria());
			$comando->execute();
			$resultado = $comando->fetchAll(PDO::FETCH_OBJ);
			$this->conexao = null;
			return $resultado;	
		}
	}
?>