<?php
	class Usuario
	{
		private $idusuario;
		private $nome;
		private $email;
		private $senha;
		private $perfil;
		
		public function __construct($idusuario, $nome, $email, $senha, $perfil)
		{
			$this->idusuario = $idusuario;
			$this->nome = $nome;
			$this->email = $email;
			$this->senha = $senha;
			$this->perfil = $perfil;
		}//fim construtor
		//métodos gets
		public function getIdusuario()
		{
			return $this->idusuario;
		}
		public function getNome()
		{
			return $this->nome;
		}
		public function getEmail()
		{
			return $this->email;
		}
		public function getSenha()
		{
			return $this->senha;
		}
		public function getPerfil()
		{
			return $this->perfil;
		}
		
}//fim classe

?>