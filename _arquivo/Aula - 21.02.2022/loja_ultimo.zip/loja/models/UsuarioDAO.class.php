<?php
	class UsuarioDAO extends Conexao
	{
		public function __construct()
		{
			parent:: __construct();
		}//fim construtor
		
		public function autenticar($usuario)
		{
			$sql = "SELECT idusuario, nome, perfil FROM usuario WHERE email = ? AND senha = ?";
			try
			{
				$stm = $this->conexao->prepare($sql);
				$stm->bindValue(1, $usuario->getEmail());
				$stm->bindValue(2, $usuario->getSenha());
				$stm->execute();
				$this->conexao = null;
				return $stm->fetchAll(PDO::FETCH_OBJ);
				
			}
			catch(PDOException $e)
			{
				return "Problema na autenticação do usuário";
			}
		}
	}//fim da classe
?>