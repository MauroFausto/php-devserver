<?php
	if($_POST)
	{
		//verificar os dados enviados
		require_once "../models/Conexao.class.php";
		require_once "../models/Fornecedor.class.php";
		require_once "../models/FornecedorDAO.class.php";
		
		$fornecedor = new Fornecedor($_POST["id"], $_POST["razao"], $_POST["cnpj"], $_POST["telefone"]);
		
		$fornecedorDAO = new FornecedorDAO();
		
		$retorno = $fornecedorDAO->alterar($fornecedor);
		
		header("Location:listar_Fornecedor.php?msg=$retorno");
	}
	else
	{
		header("Location:listar_Fornecedor.php");
	}
?>