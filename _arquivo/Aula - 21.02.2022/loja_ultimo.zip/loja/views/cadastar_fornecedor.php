<?php
	if($_POST)
	{
		//verificações
		require_once "../models/Conexao.class.php";
		require_once "../models/Fornecedor.class.php";
		require_once "../models/FornecedorDAO.class.php";
		
		
		
			$fornecedor = new Fornecedor(null, $_POST["razao"], $_POST["cnpj"], $_POST["telefone"]);
			
			
			$fornecedorDAO = new FornecedorDAO();
			
				$retorno = $fornecedorDAO->inserir($fornecedor);
			
				header("location:listar_Fornecedor.php?msg=$retorno");
		
	}
	else
	{
		header("location:listar_Fornecedor.php");
	}
?>