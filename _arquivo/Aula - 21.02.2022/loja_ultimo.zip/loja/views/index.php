<?php
	require_once "cabecalho.php";
	
	echo "<h1>index</h1>";
	
		
	require_once "rodape.html";
?>