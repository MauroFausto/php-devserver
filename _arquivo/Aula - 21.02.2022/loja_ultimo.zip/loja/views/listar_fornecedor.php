<?php
	require_once "cabecalho.php";
?>
	<div class="content">
		<div class="container">
		<br><br><div class="row justify-content-center align-items-center">
		
      <h1 class="row justify-content-center align-items-center">Lista de Fornecedores</h1><br>
  </div><br><br>
		<div>
		<?php 
			if(isset($_GET["msg"]))
			{
				echo $_GET["msg"];
			}
		?>
		</div>
		<table class="table table-striped">
			<tr>
				<th>Razão Social</th>
				<th style="text-align:center;">CNPJ</th>
				<th style="text-align:center;">Telefone</th>
				<th style="text-align:center;">Ações</th>
			</tr>
			<?php
				require_once "../models/Conexao.class.php";
				require_once "../models/FornecedorDAO.class.php";
				$fornecedorDAO = new FornecedorDAO();
				//método consultar
				$retorno = $fornecedorDAO->consultar();
				
				
				//criar as tds
				if(is_array($retorno))
				{
					foreach($retorno as $dado)
					{
						echo "<tr>";
						echo "<td>{$dado->razao_social}</td>";
						echo "<td style='text-align:center;'>{$dado->cnpj}</td>";
						echo "<td style='text-align:center;'>{$dado->telefone}</td>";
						echo "<td style='text-align:center;'>
						<a href='edit_fornecedor.php?id={$dado->idfornecedor}' class='btn btn-warning btn-sm'>Alterar</a>&nbsp;&nbsp;";
					?>	
						<a class='btn btn-danger btn-sm' href="excluir_fornecedor.php?id=<?php echo $dado->idfornecedor; ?>" onclick="return confirm('Confirma a exclusão do fornecedor?')">Excluir</a>
						
						</td>
						</tr>
					<?php
					}
				}
			?>
		</table>
		<br><br><a href="form_fornecedor.php" class='btn btn-success btn-sm'>Novo Fornecedor</a>
	</body>
</html>