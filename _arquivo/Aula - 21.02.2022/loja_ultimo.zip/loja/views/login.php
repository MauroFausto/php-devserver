<?php
	require "cabecalho.php";
	if($_POST)
	{
		$erro = false;
		//verificar preenchimento
		if($_POST["email"] == "")
		{
			echo "<script>alert('Preencha o usuário')</script>";
			$erro=true;
		}
		if($_POST["senha"] == "")
		{
			echo "<script>alert('Preencha a senha')</script>";
			$erro=true;
		}
		
		//se estiver ok 
		
		
		if(!$erro)
		{
			
			//verificar usuario e senha no BD
			require_once "../models/conexao.class.php";
			require_once "../models/usuario.class.php";
			require_once "../models/usuarioDAO.class.php";
			
			$usuario = new usuario(null, null, $_POST["email"], md5($_POST["senha"]), null);
			
			$usuarioDAO = new usuarioDAO();
			$retorno = $usuarioDAO->autenticar($usuario);
			if(is_array($retorno)) 
				if(count($retorno) > 0)
				{
					//é um usuário
					//guarda os dados do usuário na Sessão
					if(!isset($_SESSION))
						session_start();
					
					$_SESSION["idusuario"] = $retorno[0]->idusuario;
					$_SESSION["nome"] = $retorno[0]->nome;
					$_SESSION["perfil"] = $retorno[0]->perfil;
					
					header("location:index.php");
				}
				else
				{
					//não é um usuário
					echo "<script>alert('Usuário/Senha não conferem')</script>";
				}
			}
			else
			{
				echo "<script>alert(" . $retorno . ")</script>";
			}
			
		}
		
	
	
?>
<div class="content">
	<div class="container">
	<form action="#" method="POST">
	
		<div class="box">
			
			<br><br><img class="col-sm-1" style="margin-left:200px" src="../imagens/usuario1.png">
			<div class="form-group">
			<div class="row justify-content-center align-items-center">
				<label class="col-sm-2 col-form-label col-form-label-lg">Usuário</label>
				<div class="col-sm-6">
					<input type="email"  class="form-control form-control-lg" placeholder="Seu E-mail" name="email">
				</div>
			</div>
			</div><br>
		<div class="form-group">
		<div class="row justify-content-center align-items-center">
			<label class="col-sm-2 col-form-label col-form-label-lg">Senha</label>
			<div class="col-sm-6">
				<input type="password" class="form-control form-control-lg" placeholder="Sua senha" name="senha">
			</div>
		</div>
		</div>
		<br><br><div class="form-group">
		<div class="row justify-content-center align-items-center">
			<input type="submit"  class="btn btn-lg btn-success col-sm-2" value="Enviar">
		</div>
		</div>
	</div>
</form>
<?php
	require "rodape.html";
?>